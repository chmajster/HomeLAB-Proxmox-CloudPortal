(() => {
  'use strict';

  const body = document.body;
  const content = document.getElementById('appContent');
  if (!content) return;

  const page = body.dataset.page || 'dashboard';
  const basePath = body.dataset.basePath || '';
  const appUrl = path => `${basePath}${path}`;
  const csrf = body.dataset.csrf || '';
  const isAdmin = body.dataset.admin === '1';
  const locale = document.documentElement.lang === 'en' ? 'en' : 'pl';
  const tr = {
    pl: {
      dashboard: 'Dashboard', vms: 'Maszyny wirtualne', 'create-vm': 'Utwórz maszynę', projects: 'Projekty', networks: 'Sieci', templates: 'Template', activity: 'Aktywność', users: 'Użytkownicy', infrastructure: 'Infrastruktura', proxmox: 'Połączenia Proxmox', storages: 'Storage', plans: 'Plany zasobów', quotas: 'Quota', audit: 'Audit log', settings: 'Ustawienia',
      error: 'Wystąpił błąd', empty: 'Brak danych do wyświetlenia.', loading: 'Ładowanie…', saved: 'Zapisano zmiany.', queued: 'Operacja została dodana do kolejki.', confirm: 'Czy na pewno chcesz wykonać tę operację?', cancel: 'Anuluj'
    },
    en: {
      dashboard: 'Dashboard', vms: 'Virtual machines', 'create-vm': 'Create virtual machine', projects: 'Projects', networks: 'Networks', templates: 'Templates', activity: 'Activity', users: 'Users', infrastructure: 'Infrastructure', proxmox: 'Proxmox connections', storages: 'Storage', plans: 'Resource plans', quotas: 'Quotas', audit: 'Audit log', settings: 'Settings',
      error: 'An error occurred', empty: 'No data to display.', loading: 'Loading…', saved: 'Changes saved.', queued: 'The operation has been queued.', confirm: 'Are you sure you want to perform this operation?', cancel: 'Cancel'
    }
  }[locale];

  const h = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const icon = (name, className = 'ui-icon') => `<svg class="${h(className)}" aria-hidden="true"><use href="${appUrl('/assets/icons.svg')}#i-${h(name)}"></use></svg>`;
  const fmt = value => new Intl.NumberFormat(locale === 'pl' ? 'pl-PL' : 'en-US').format(Number(value || 0));
  const date = value => value ? new Intl.DateTimeFormat(locale === 'pl' ? 'pl-PL' : 'en-US', {dateStyle:'medium', timeStyle:'short'}).format(new Date(String(value).replace(' ', 'T') + 'Z')) : '—';
  const status = value => `<span class="status-badge status-${h(String(value || 'unknown').replace('running', 'running'))}">${h(value || 'unknown')}</span>`;

  async function api(url, options = {}) {
    const init = {...options, headers: {'Accept':'application/json', ...(options.body ? {'Content-Type':'application/json'} : {}), ...(['GET','HEAD'].includes(options.method || 'GET') ? {} : {'X-CSRF-Token':csrf}), ...(options.headers || {})}};
    if (options.body && typeof options.body !== 'string') init.body = JSON.stringify(options.body);
    const response = await fetch(url.startsWith('/') ? appUrl(url) : url, init);
    const type = response.headers.get('content-type') || '';
    if (!type.includes('application/json')) {
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return response;
    }
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error?.message || `HTTP ${response.status}`);
    return payload.data;
  }

  function toast(message, kind = 'success') {
    const container = document.getElementById('toastContainer');
    const element = document.createElement('div');
    element.className = `toast align-items-center text-bg-${kind} border-0`;
    element.setAttribute('role', 'status');
    element.innerHTML = `<div class="d-flex"><div class="toast-body">${h(message)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Zamknij"></button></div>`;
    container.append(element);
    const instance = new bootstrap.Toast(element, {delay: 5000});
    element.addEventListener('hidden.bs.toast', () => element.remove());
    instance.show();
  }

  function showError(error) {
    content.innerHTML = `<div class="alert alert-danger" role="alert"><h2 class="h5 d-flex align-items-center gap-2">${icon('alert-circle')}${h(tr.error)}</h2><p class="mb-0">${h(error.message || error)}</p></div>`;
    toast(error.message || String(error), 'danger');
  }

  let confirmCallback = null;
  function confirmAction(message, callback) {
    document.getElementById('confirmTitle').textContent = locale === 'pl' ? 'Potwierdź operację' : 'Confirm operation';
    document.getElementById('confirmMessage').textContent = message || tr.confirm;
    const button = document.getElementById('confirmAction');
    button.classList.remove('d-none');
    confirmCallback = callback;
    bootstrap.Modal.getOrCreateInstance(document.getElementById('confirmModal')).show();
  }
  document.getElementById('confirmAction').addEventListener('click', async () => {
    const callback = confirmCallback;
    confirmCallback = null;
    bootstrap.Modal.getOrCreateInstance(document.getElementById('confirmModal')).hide();
    if (callback) await callback();
  });

  const menuButton = document.getElementById('menuButton');
  const closeMenu = () => { body.classList.remove('menu-open'); menuButton?.setAttribute('aria-expanded', 'false'); };
  menuButton?.addEventListener('click', () => { const open = body.classList.toggle('menu-open'); menuButton.setAttribute('aria-expanded', String(open)); });
  document.getElementById('sidebarBackdrop')?.addEventListener('click', closeMenu);
  document.querySelectorAll('.portal-nav a').forEach(link => link.addEventListener('click', closeMenu));

  const themeButton = document.getElementById('themeButton');
  const storedTheme = localStorage.getItem('portal-theme');
  if (storedTheme === 'light' || storedTheme === 'dark') document.documentElement.dataset.bsTheme = storedTheme;
  themeButton?.addEventListener('click', () => {
    const next = document.documentElement.dataset.bsTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.bsTheme = next;
    localStorage.setItem('portal-theme', next);
  });
  document.getElementById('logoutButton')?.addEventListener('click', async () => { await api('/api/v1/logout', {method:'POST'}); location.assign(appUrl('/login')); });
  document.querySelector('[data-dismiss-checklist]')?.addEventListener('click', () => document.getElementById('firstRunChecklist')?.remove());
  document.getElementById('pageTitle').textContent = tr[page] || page;

  const metric = (label, value, foot = '') => `<div class="metric-card"><div class="metric-label">${h(label)}</div><div class="metric-value">${h(value)}</div><div class="metric-foot">${h(foot)}</div></div>`;
  const usage = (label, used, max, unit = '') => { const safeMax=Math.max(0,Number(max||0)),safeUsed=Math.max(0,Number(used||0)); return `<div class="usage-row"><div class="usage-head"><span>${h(label)}</span><span>${h(fmt(safeUsed))}${h(unit)} / ${h(fmt(safeMax))}${h(unit)}</span></div><progress class="usage-progress" value="${Math.min(safeUsed,safeMax)}" max="${safeMax||1}">${safeMax?Math.round(safeUsed/safeMax*100):0}%</progress></div>`; };
  const empty = () => `<div class="empty-state">${icon('inbox')}<span>${h(tr.empty)}</span></div>`;

  async function dashboard() {
    const data = await api('/api/v1/dashboard');
    const s = data.summary || {};
    let cards = metric('VM', fmt(s.vms), `${fmt(s.running)} running · ${fmt(s.stopped)} stopped`) +
      metric('vCPU', fmt(s.vcpu), locale === 'pl' ? 'przydzielone' : 'allocated') +
      metric('RAM', `${fmt(Math.round((s.ram_mb || 0) / 1024))} GB`, locale === 'pl' ? 'przydzielona' : 'allocated') +
      metric('Storage', `${fmt(s.storage_gb)} GB`, locale === 'pl' ? 'przydzielony' : 'allocated');
    if (isAdmin && data.admin_counts) {
      cards += metric(locale === 'pl' ? 'Użytkownicy' : 'Users', fmt(data.admin_counts.users)) + metric(locale === 'pl' ? 'Projekty' : 'Projects', fmt(data.admin_counts.projects)) + metric('Proxmox', fmt(data.admin_counts.proxmox_connections), `${fmt(data.admin_counts.proxmox_nodes)} nodes`);
    }
    const vmRows = (data.recent_vms || []).map(vm => `<tr><td><a class="vm-name" href="${appUrl('/vms')}" data-vm-id="${vm.id}">${h(vm.name)}</a><div class="resource-meta">VMID ${h(vm.vmid)}</div></td><td>${status(vm.status)}</td><td>${fmt(vm.vcpu)} / ${fmt(Math.round(vm.ram_mb/1024))} GB / ${fmt(vm.disk_gb)} GB</td><td>${date(vm.created_at)}</td></tr>`).join('');
    const jobItems = (data.recent_jobs || []).map(job => `<li class="activity-item"><span class="activity-dot"></span><span><strong>${h(job.type)}</strong><small class="d-block text-secondary">${h(job.vm_name || job.public_id)}</small></span>${status(job.status)}</li>`).join('');
    let infra = '';
    if (isAdmin && data.infrastructure) {
      infra = `<div class="panel mt-3"><div class="panel-header"><h2 class="h5 mb-0">Proxmox live</h2><a href="${appUrl('/infrastructure')}" class="btn btn-sm btn-outline-primary">${locale === 'pl' ? 'Szczegóły' : 'Details'}</a></div><div class="panel-body"><div class="row g-3">${data.infrastructure.map(cluster => {
        const nodes = cluster.resources.filter(r => r.type === 'node');
        const vms = cluster.resources.filter(r => r.type === 'qemu');
        const lxc = cluster.resources.filter(r => r.type === 'lxc');
        return `<div class="col-md-6"><div class="cluster-card"><div class="d-flex justify-content-between"><strong>${h(cluster.connection.name)}</strong>${cluster.error ? status('error') : status('active')}</div><div class="resource-meta mt-2">${nodes.length} nodes · ${vms.length} VM · ${lxc.length} LXC</div>${cluster.error ? `<div class="text-danger small mt-2">${h(cluster.error)}</div>` : ''}</div></div>`;
      }).join('')}</div></div></div>`;
      const taskRows=(data.proxmox_tasks||[]).map(task=>`<tr><td>${h(task.cluster)}</td><td>${h(task.type||'task')}</td><td>${h(task.node||'—')}</td><td>${status(task.status||task.exitstatus||'running')}</td></tr>`).join('');
      const errorRows=(data.recent_errors||[]).map(error=>`<tr><td>${date(error.created_at)}</td><td>${h(error.type)}</td><td class="text-danger">${h(error.error_message)}</td></tr>`).join('');
      infra += `<div class="content-grid"><section class="panel"><div class="panel-header"><h2 class="h5 mb-0">Proxmox tasks</h2></div><div class="table-responsive"><table class="table"><thead><tr><th>Cluster</th><th>Task</th><th>Node</th><th>Status</th></tr></thead><tbody>${taskRows||`<tr><td colspan="4">${empty()}</td></tr>`}</tbody></table></div></section><section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${locale==='pl'?'Ostatnie błędy':'Recent errors'}</h2></div><div class="table-responsive"><table class="table"><tbody>${errorRows||`<tr><td>${empty()}</td></tr>`}</tbody></table></div></section></div>`;
    }
    let quotaPanel = '';
    if (!isAdmin && data.quota) quotaPanel = `<section class="panel mt-3"><div class="panel-header"><h2 class="h5 mb-0">Quota</h2></div><div class="panel-body">${usage('VM',s.vms,data.quota.max_vms)}${usage('vCPU',s.vcpu,data.quota.max_vcpu)}${usage('RAM',Math.round(s.ram_mb/1024),Math.round(data.quota.max_ram_mb/1024),' GB')}${usage('Storage',s.storage_gb,data.quota.max_storage_gb,' GB')}</div></section>`;
    if (isAdmin && data.admin_usage) { const u=data.admin_usage; quotaPanel=`<section class="panel mt-3"><div class="panel-header"><h2 class="h5 mb-0">Infrastructure utilization</h2></div><div class="panel-body">${usage('CPU',Math.round(u.cpu_used*10)/10,u.cpu_total,' cores')}${usage('RAM',Math.round(u.ram_used/1073741824),Math.round(u.ram_total/1073741824),' GB')}${usage('Storage',Math.round(u.storage_used/1073741824),Math.round(u.storage_total/1073741824),' GB')}</div></section>`; }
    content.innerHTML = `<div class="metric-grid">${cards}</div><div class="content-grid"><section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${locale === 'pl' ? 'Ostatnie maszyny' : 'Recent machines'}</h2><a class="btn btn-sm btn-outline-primary" href="${appUrl('/vms')}">${locale === 'pl' ? 'Wszystkie' : 'View all'}</a></div><div class="table-responsive"><table class="table"><thead><tr><th>Name</th><th>Status</th><th>Resources</th><th>Created</th></tr></thead><tbody>${vmRows || `<tr><td colspan="4">${empty()}</td></tr>`}</tbody></table></div></section><section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${locale === 'pl' ? 'Ostatnie operacje' : 'Recent operations'}</h2></div><div class="panel-body"><ul class="activity-list">${jobItems || empty()}</ul></div></section></div>${quotaPanel}${infra}`;
  }

  async function vmList() {
    const vms = await api('/api/v1/vms');
    const rows = vms.map(vm => `<tr><td><button class="btn btn-link p-0 vm-name text-start" data-action="details" data-id="${vm.id}">${h(vm.name)}</button><div class="resource-meta">VMID ${h(vm.vmid)}</div></td>${isAdmin ? `<td>${h(vm.owner_name)}</td><td>${h(vm.project_name)}</td>` : ''}<td>${h(vm.node_name)}</td><td>${status(vm.status)}</td><td>${fmt(vm.vcpu)}</td><td>${fmt(Math.round(vm.ram_mb/1024))} GB</td><td>${fmt(vm.disk_gb)} GB</td><td>${h(vm.ip_address || '—')}</td><td><div class="actions"><button class="btn btn-outline-success" data-action="start" data-id="${vm.id}">${icon('play')}Start</button><button class="btn btn-outline-secondary" data-action="shutdown" data-id="${vm.id}">${icon('power')}Shutdown</button><button class="btn btn-outline-danger" data-action="stop" data-id="${vm.id}">${icon('stop')}Stop</button><button class="btn btn-outline-primary" data-action="reboot" data-id="${vm.id}">${icon('refresh')}Reboot</button><button class="btn btn-outline-primary" data-action="console" data-id="${vm.id}">${icon('terminal')}Console</button><button class="btn btn-outline-secondary" data-action="snapshot" data-id="${vm.id}">${icon('camera')}Snapshot</button><button class="btn btn-outline-secondary" data-action="resize" data-id="${vm.id}">${icon('maximize')}Resize</button>${isAdmin ? `<button class="btn btn-outline-secondary" data-action="assign" data-id="${vm.id}">${icon('user-plus')}Assign</button>` : ''}<button class="btn btn-outline-danger" data-action="delete" data-id="${vm.id}">${icon('trash')}Delete</button></div></td></tr>`).join('');
    content.innerHTML = `<section class="panel"><div class="panel-header"><div><h2 class="h5 mb-1">${tr.vms}</h2><p class="text-secondary small mb-0">${locale === 'pl' ? 'Stan jest synchronizowany z API Proxmox.' : 'Status is synchronized with the Proxmox API.'}</p></div><a href="${appUrl('/create-vm')}" class="btn btn-primary">${icon('plus')}${locale === 'pl' ? 'Utwórz VM' : 'Create VM'}</a></div><div class="table-responsive"><table class="table"><thead><tr><th>Name</th>${isAdmin ? '<th>Owner</th><th>Project</th>' : ''}<th>Node</th><th>Status</th><th>CPU</th><th>RAM</th><th>Disk</th><th>IP</th><th>Actions</th></tr></thead><tbody>${rows || `<tr><td colspan="11">${empty()}</td></tr>`}</tbody></table></div></section>`;
    content.addEventListener('click', vmAction);
  }

  async function vmAction(event) {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const id = Number(button.dataset.id);
    const action = button.dataset.action;
    if (action === 'details') return vmDetails(id);
    if (action === 'console') return openConsole(id);
    if (action === 'snapshot') {
      const name = prompt(locale === 'pl' ? 'Nazwa snapshotu:' : 'Snapshot name:');
      if (name) queue(`/api/v1/vms/${id}/snapshots`, 'POST', {name});
      return;
    }
    if (action === 'resize') {
      const plan = prompt(locale === 'pl' ? 'ID większego planu zasobów:' : 'Larger resource plan ID:');
      if (plan) queue(`/api/v1/vms/${id}/resize`, 'POST', {plan_id:Number(plan)});
      return;
    }
    if (action === 'assign') {
      const projectId = prompt('Target project ID:'); if (!projectId) return;
      const ownerId = prompt('Target owner user ID:'); if (!ownerId) return;
      confirmAction(tr.confirm, async () => { try { await api(`/api/v1/vms/${id}/assignment`, {method:'PATCH', body:{project_id:Number(projectId), owner_user_id:Number(ownerId)}}); toast(tr.saved); vmList(); } catch(error) { toast(error.message,'danger'); } });
      return;
    }
    const destructive = ['stop','delete'].includes(action);
    const run = () => queue(`/api/v1/vms/${id}${action === 'delete' ? '' : '/' + action}`, action === 'delete' ? 'DELETE' : 'POST');
    if (destructive) confirmAction(`${tr.confirm} (${action})`, run); else run();
  }

  async function queue(url, method, payload) {
    try {
      const result = await api(url, {method, ...(payload ? {body:payload} : {})});
      toast(tr.queued);
      if (result.job_id) pollJob(result.job_id);
    } catch (error) { toast(error.message, 'danger'); }
  }

  async function pollJob(jobId) {
    let attempts = 0;
    const poll = async () => {
      try {
        const job = await api(`/api/v1/jobs/${encodeURIComponent(jobId)}`);
        if (job.status === 'completed') { toast(`${job.type}: completed`); if (page === 'vms') vmList(); return; }
        if (job.status === 'failed') { toast(job.error_message || `${job.type}: failed`, 'danger'); if (page === 'vms') vmList(); return; }
        if (++attempts < 180) setTimeout(poll, 2000);
      } catch (error) { if (++attempts < 10) setTimeout(poll, 3000); }
    };
    setTimeout(poll, 1000);
  }

  async function vmDetails(id) {
    try {
      const data = await api(`/api/v1/vms/${id}`);
      const vm = data.vm;
      document.getElementById('confirmTitle').textContent = vm.name;
      document.getElementById('confirmMessage').innerHTML = `<div class="summary-list"><div class="summary-item"><small>VMID</small>${h(vm.vmid)}</div><div class="summary-item"><small>Status</small>${status(vm.status)}</div><div class="summary-item"><small>Project</small>${h(vm.project_name)}</div><div class="summary-item"><small>Owner</small>${h(vm.owner_name)}</div><div class="summary-item"><small>Resources</small>${fmt(vm.vcpu)} vCPU · ${fmt(Math.round(vm.ram_mb/1024))} GB · ${fmt(vm.disk_gb)} GB</div><div class="summary-item"><small>IP</small>${h(vm.ip_address || '—')}</div></div><h3 class="h6 mt-4">Snapshots</h3>${data.snapshots.length ? data.snapshots.map(s => `<div class="d-flex justify-content-between align-items-center border-bottom py-2"><span>${h(s.name)} ${status(s.status)}</span><button class="btn btn-sm btn-outline-danger" data-delete-snapshot="${s.id}" data-vm="${vm.id}">${icon('trash')}Delete</button></div>`).join('') : `<p class="text-secondary">${tr.empty}</p>`}<h3 class="h6 mt-4">Jobs</h3>${data.jobs.slice(0,5).map(j => `<div class="d-flex justify-content-between border-bottom py-2"><span>${h(j.type)}</span>${status(j.status)}</div>`).join('') || `<p class="text-secondary">${tr.empty}</p>`}`;
      document.getElementById('confirmAction').classList.add('d-none');
      bootstrap.Modal.getOrCreateInstance(document.getElementById('confirmModal')).show();
      document.getElementById('confirmMessage').querySelectorAll('[data-delete-snapshot]').forEach(button => button.addEventListener('click', () => {
        bootstrap.Modal.getOrCreateInstance(document.getElementById('confirmModal')).hide();
        confirmAction(tr.confirm, () => queue(`/api/v1/vms/${button.dataset.vm}/snapshots/${button.dataset.deleteSnapshot}`, 'DELETE'));
      }));
    } catch (error) { toast(error.message, 'danger'); }
  }

  async function openConsole(id) {
    try {
      const response = await api(`/api/v1/vms/${id}/console`, {method:'POST'});
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a'); link.href = url; link.download = 'console.vv'; link.click(); URL.revokeObjectURL(url);
      toast(locale === 'pl' ? 'Pobrano konfigurację konsoli SPICE.' : 'SPICE console configuration downloaded.');
    } catch (error) { toast(error.message, 'danger'); }
  }

  async function createVmWizard() {
    const catalog = await api('/api/v1/catalog');
    if (!catalog.projects.length) { content.innerHTML = `<div class="alert alert-warning">${locale === 'pl' ? 'Nie należysz do aktywnego projektu. Administrator musi przypisać projekt i quota.' : 'You are not assigned to an active project. An administrator must assign a project and quota.'}</div>`; return; }
    content.innerHTML = `<div class="wizard-shell"><div class="wizard-steps" aria-label="Wizard progress">${Array.from({length:12},(_,i)=>`<span class="wizard-step ${i===0?'active':''}"></span>`).join('')}</div><form class="panel" id="vmWizard"><div class="panel-body p-4 p-md-5">
      ${wizardPage(1,'Nazwa i projekt',`<div class="mb-3"><label class="form-label" for="vmName">Nazwa VM</label><input class="form-control form-control-lg" id="vmName" name="name" pattern="[A-Za-z0-9][A-Za-z0-9-]{1,62}" required></div><div><label class="form-label" for="projectId">Projekt</label><select class="form-select form-select-lg" id="projectId" name="project_id" required>${catalog.projects.map(p=>`<option value="${p.id}">${h(p.name)}</option>`).join('')}</select></div>`)}
      ${wizardPage(2,'System / template','<div id="templateChoices" class="plan-grid"></div>')}
      ${wizardPage(3,'CPU','<div id="planChoices" class="plan-grid"></div>')}
      ${wizardPage(4,'RAM','<div id="ramPreview"></div>')}
      ${wizardPage(5,'Dysk','<div id="diskPreview"></div>')}
      ${wizardPage(6,'Storage','<div id="storageChoices" class="plan-grid"></div>')}
      ${wizardPage(7,'Sieć','<div id="networkChoices" class="plan-grid"></div>')}
      ${wizardPage(8,'VLAN','<div id="vlanPreview"></div>')}
      ${wizardPage(9,'Cloud-init','<label class="form-label" for="cloudUser">Użytkownik systemu</label><input class="form-control" id="cloudUser" name="cloud_init_user" value="clouduser" pattern="[a-z_][a-z0-9_-]{0,31}" required>')}
      ${wizardPage(10,'Klucz SSH','<label class="form-label" for="sshKey">Publiczny klucz SSH</label><textarea class="form-control" id="sshKey" name="ssh_public_key" rows="5" required></textarea><div class="form-text">ssh-ed25519, ssh-rsa lub ECDSA</div>')}
      ${wizardPage(11,'Podsumowanie','<div id="wizardSummary" class="summary-list"></div><div class="form-check mt-4"><input class="form-check-input" type="checkbox" id="startAfter" name="start_after_create" checked><label class="form-check-label" for="startAfter">Uruchom VM po utworzeniu</label></div>')}
      ${wizardPage(12,'Utwórz',`<div class="text-center py-4"><div class="wizard-success-icon mb-3">${icon('check')}</div><h3>Gotowe do provisioningu</h3><p class="text-secondary">Quota i adres IP zostaną zarezerwowane atomowo. Postęp będzie śledzony przez job Proxmox.</p></div>`)}
      </div><div class="panel-header"><button type="button" class="btn btn-outline-secondary" id="wizardBack" disabled>${icon('arrow-left')}Wstecz</button><span class="text-secondary small" id="wizardCounter">1 / 12</span><button type="button" class="btn btn-primary" id="wizardNext">Dalej${icon('arrow-right')}</button></div></form></div>`;
    const state = {step:1, catalog};
    const form = document.getElementById('vmWizard');
    const loadProject = async () => { state.catalog = await api(`/api/v1/catalog?project_id=${encodeURIComponent(form.elements.project_id.value)}`); renderChoices(state); };
    form.elements.project_id.addEventListener('change', loadProject);
    await loadProject();
    document.getElementById('wizardBack').addEventListener('click', () => changeWizard(state, -1));
    document.getElementById('wizardNext').addEventListener('click', async () => {
      if (!validateWizardStep(state.step, form)) return;
      if (state.step === 11) buildSummary(form, state.catalog);
      if (state.step < 12) return changeWizard(state, 1);
      const raw = Object.fromEntries(new FormData(form));
      raw.project_id = Number(raw.project_id); raw.template_id = Number(raw.template_id); raw.plan_id = Number(raw.plan_id); raw.storage_id = Number(raw.storage_id); raw.network_id = Number(raw.network_id); raw.start_after_create = form.elements.start_after_create.checked;
      const button = document.getElementById('wizardNext'); button.disabled = true; button.innerHTML = tr.loading;
      try { const result = await api('/api/v1/vms', {method:'POST', body:raw}); toast(tr.queued); pollJob(result.job_id); location.assign(appUrl('/activity')); }
      catch (error) { button.disabled=false; button.innerHTML=`Create${icon('arrow-right')}`; toast(error.message,'danger'); }
    });
  }

  function wizardPage(number, title, inner) { return `<section class="wizard-page ${number===1?'active':''}" data-step="${number}"><p class="eyebrow">Krok ${number} / 12</p><h2 class="h3 mb-4">${h(title)}</h2>${inner}</section>`; }
  function renderChoices(state) {
    const c = state.catalog;
    document.getElementById('templateChoices').innerHTML = c.templates.map((x,i)=>selectCard('template_id',x.id,x.name,x.operating_system||'',i===0)).join('') || empty();
    document.getElementById('planChoices').innerHTML = c.plans.map((x,i)=>selectCard('plan_id',x.id,x.name,`${x.vcpu} vCPU · ${Math.round(x.ram_mb/1024)} GB · ${x.disk_gb} GB`,i===0)).join('') || empty();
    const renderDependent = () => {
      const template=c.templates.find(x=>String(x.id)===document.querySelector('[name="template_id"]:checked')?.value);
      const compatible=x=>template&&Number(x.connection_id)===Number(template.connection_id)&&(!x.node_name||x.node_name===template.node_name);
      const storages=c.storages.filter(compatible),networks=c.networks.filter(compatible);
      document.getElementById('storageChoices').innerHTML = storages.map((x,i)=>selectCard('storage_id',x.id,x.storage_name,x.node_name||'cluster',i===0)).join('') || empty();
      document.getElementById('networkChoices').innerHTML = networks.map((x,i)=>selectCard('network_id',x.id,x.name,`${x.bridge} · ${x.subnet}`,i===0)).join('') || empty();
    };
    document.querySelectorAll('[name="template_id"]').forEach(input=>input.addEventListener('change',renderDependent));
    renderDependent();
  }
  function selectCard(name,id,title,meta,checked) { return `<label class="select-card"><input type="radio" name="${name}" value="${id}" ${checked?'checked':''} required><strong class="d-block">${h(title)}</strong><span class="resource-meta">${h(meta)}</span></label>`; }
  function validateWizardStep(step, form) {
    const section = form.querySelector(`[data-step="${step}"]`);
    for (const input of section.querySelectorAll('input,select,textarea')) if (!input.checkValidity()) { input.reportValidity(); return false; }
    const requiredByStep = {2:'template_id',3:'plan_id',6:'storage_id',7:'network_id'}[step];
    if (requiredByStep && !form.querySelector(`[name="${requiredByStep}"]:checked`)) { toast(locale === 'pl' ? 'Wybierz jedną opcję.' : 'Select an option.', 'warning'); return false; }
    return true;
  }
  function changeWizard(state, delta) {
    state.step = Math.max(1, Math.min(12, state.step + delta));
    document.querySelectorAll('.wizard-page').forEach(x=>x.classList.toggle('active',Number(x.dataset.step)===state.step));
    document.querySelectorAll('.wizard-step').forEach((x,i)=>{x.classList.toggle('active',i+1===state.step);x.classList.toggle('done',i+1<state.step);});
    document.getElementById('wizardBack').disabled = state.step === 1;
    document.getElementById('wizardNext').innerHTML = `${state.step === 12 ? 'Create' : 'Dalej'}${icon('arrow-right')}`;
    document.getElementById('wizardCounter').textContent = `${state.step} / 12`;
    const form = document.getElementById('vmWizard');
    const plan = state.catalog.plans.find(x=>String(x.id)===form.elements.plan_id?.value);
    const network = state.catalog.networks.find(x=>String(x.id)===form.elements.network_id?.value);
    if (state.step===4) document.getElementById('ramPreview').innerHTML = plan ? metric('RAM',`${Math.round(plan.ram_mb/1024)} GB`,plan.name) : empty();
    if (state.step===5) document.getElementById('diskPreview').innerHTML = plan ? metric('Disk',`${plan.disk_gb} GB`,plan.name) : empty();
    if (state.step===8) document.getElementById('vlanPreview').innerHTML = network ? metric('VLAN',network.vlan_id||'untagged',`${network.bridge} · ${network.subnet}`) : empty();
    if (state.step===11) buildSummary(form,state.catalog);
  }
  function buildSummary(form,c) {
    const plan=c.plans.find(x=>String(x.id)===form.elements.plan_id.value), template=c.templates.find(x=>String(x.id)===form.elements.template_id.value), network=c.networks.find(x=>String(x.id)===form.elements.network_id.value), storage=c.storages.find(x=>String(x.id)===form.elements.storage_id.value);
    const items=[['Name',form.elements.name.value],['Project',form.elements.project_id.selectedOptions[0]?.textContent],['Template',template?.name],['Plan',plan?`${plan.name}: ${plan.vcpu} vCPU / ${Math.round(plan.ram_mb/1024)} GB / ${plan.disk_gb} GB`:''],['Storage',storage?.storage_name],['Network',network?`${network.name} / VLAN ${network.vlan_id||'untagged'}`:''],['Cloud-init',form.elements.cloud_init_user.value],['SSH',form.elements.ssh_public_key.value.split(' ').slice(0,2).join(' ')]];
    document.getElementById('wizardSummary').innerHTML=items.map(([k,v])=>`<div class="summary-item"><small>${h(k)}</small>${h(v||'—')}</div>`).join('');
  }

  async function simpleResource(resource) {
    const data = await api(`/api/v1/${resource}`);
    const keys = data.length ? Object.keys(data[0]).filter(k=>!['description'].includes(k)) : [];
    content.innerHTML = `<section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${h(tr[resource]||resource)}</h2></div>${data.length ? `<div class="table-responsive"><table class="table"><thead><tr>${keys.map(k=>`<th>${h(k.replaceAll('_',' '))}</th>`).join('')}</tr></thead><tbody>${data.map(row=>`<tr>${keys.map(k=>`<td>${k==='status'?status(row[k]):h(row[k]??'—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : empty()}</section>`;
  }

  async function activity() {
    const jobs = await api('/api/v1/jobs');
    content.innerHTML = `<section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${tr.activity}</h2><button class="btn btn-sm btn-outline-primary" id="refreshJobs">${icon('refresh')}Refresh</button></div><div class="table-responsive"><table class="table"><thead><tr><th>Time</th><th>Operation</th><th>VM</th><th>Status</th><th>Error</th></tr></thead><tbody>${jobs.map(j=>`<tr><td>${date(j.created_at)}</td><td>${h(j.type)}<div class="resource-meta">${h(j.public_id)}</div></td><td>${h(j.virtual_machine_id||'—')}</td><td>${status(j.status)}</td><td class="text-danger">${h(j.error_message||'')}</td></tr>`).join('')||`<tr><td colspan="5">${empty()}</td></tr>`}</tbody></table></div></section>`;
    document.getElementById('refreshJobs').addEventListener('click', activity);
    if (jobs.some(j=>['queued','running'].includes(j.status))) setTimeout(()=>{if(page==='activity')activity();},3000);
  }

  const adminForms = {
    users: `<input name="username" class="form-control" placeholder="Username" required><input name="email" type="email" class="form-control" placeholder="Email" required><select name="role" class="form-select"><option value="user">User</option><option value="admin">Admin</option></select><select name="locale" class="form-select"><option value="pl">Polski</option><option value="en">English</option></select><input name="password" type="password" class="form-control span-2" minlength="12" placeholder="Password (min. 12)" required>`,
    projects: `<input name="name" class="form-control" placeholder="Name" required><input name="slug" class="form-control" pattern="[a-z0-9][a-z0-9-]+" placeholder="slug" required><textarea name="description" class="form-control span-3" placeholder="Description"></textarea>`,
    proxmox: `<input name="name" class="form-control" placeholder="Name" required><input name="hostname" class="form-control" placeholder="pve.example.com" required><input name="port" type="number" class="form-control" value="8006" required><input name="realm" class="form-control" value="pve" required><input name="api_token_id" class="form-control" placeholder="portal!cloud" required><input name="api_token_secret" type="password" class="form-control" placeholder="Token secret" required><label class="form-check span-3"><input name="verify_ssl" class="form-check-input" type="checkbox" checked> Verify TLS certificate</label>`,
    plans: `<input name="name" class="form-control" placeholder="Name" required><input name="slug" class="form-control" placeholder="slug" required><input name="vcpu" type="number" class="form-control" placeholder="vCPU" required><input name="ram_mb" type="number" class="form-control" placeholder="RAM MB" required><input name="disk_gb" type="number" class="form-control" placeholder="Disk GB" required><label class="form-check"><input name="allow_resize" class="form-check-input" type="checkbox" checked> Allow resize</label>`,
    quotas: `<select name="subject_type" class="form-select"><option value="project">Project</option><option value="user">User</option></select><input name="subject_id" type="number" class="form-control" placeholder="Subject ID" required><input name="max_vms" type="number" class="form-control" placeholder="Max VM" required><input name="max_vcpu" type="number" class="form-control" placeholder="Max vCPU" required><input name="max_ram_mb" type="number" class="form-control" placeholder="Max RAM MB" required><input name="max_storage_gb" type="number" class="form-control" placeholder="Max storage GB" required><input name="max_snapshots" type="number" class="form-control" placeholder="Max snapshots" required><input name="max_ip_addresses" type="number" class="form-control" placeholder="Max IP (optional)">`,
    networks: `<input name="connection_id" type="number" class="form-control" placeholder="Connection ID" required><input name="name" class="form-control" placeholder="Name" required><input name="node_name" class="form-control" placeholder="Node (empty = all nodes)"><input name="bridge" class="form-control" value="vmbr0" required><input name="vlan_id" type="number" class="form-control" placeholder="VLAN (optional)"><input name="subnet" class="form-control" placeholder="192.0.2.0/24" required><input name="gateway" class="form-control" placeholder="Gateway"><input name="dns_servers" class="form-control" placeholder="DNS, comma separated"><input name="ip_start" class="form-control" placeholder="First IP" required><input name="ip_end" class="form-control" placeholder="Last IP" required>`,
    templates: `<input name="connection_id" type="number" class="form-control" placeholder="Connection ID" required><input name="node_name" class="form-control" placeholder="Node" required><input name="vmid" type="number" class="form-control" placeholder="Template VMID" required><input name="name" class="form-control" placeholder="Name" required><input name="operating_system" class="form-control" placeholder="Operating system"><textarea name="description" class="form-control span-3" placeholder="Description"></textarea>`,
    storages: `<input name="connection_id" type="number" class="form-control" placeholder="Connection ID" required><input name="node_name" class="form-control" placeholder="Node (empty = all nodes)"><input name="storage_name" class="form-control" placeholder="Proxmox storage ID" required>`,
    settings: `<input name="key" class="form-control" placeholder="setting.key" required><input name="value" class="form-control span-2" placeholder="Value" required><label class="form-check span-3"><input name="is_public" class="form-check-input" type="checkbox"> Public setting</label>`
  };

  async function adminResource(resource) {
    const data = await api(`/api/v1/admin/${resource}`);
    const keys = data.length ? Object.keys(data[0]).filter(k=>!['metadata','api_token_id'].includes(k)) : [];
    const form = adminForms[resource] || '';
    content.innerHTML = `${form ? `<section class="panel mb-3"><div class="panel-header"><h2 class="h5 mb-0">${locale==='pl'?'Dodaj':'Add'}: ${h(tr[resource]||resource)}</h2></div><form class="panel-body admin-form-grid" id="adminCreate">${form}<button class="btn btn-primary span-3" type="submit">${icon('save')}${locale==='pl'?'Zapisz':'Save'}</button></form></section>`:''}<section class="panel"><div class="panel-header"><h2 class="h5 mb-0">${h(tr[resource]||resource)}</h2></div>${data.length?`<div class="table-responsive"><table class="table"><thead><tr>${keys.map(k=>`<th>${h(k.replaceAll('_',' '))}</th>`).join('')}${['proxmox','users','projects','plans','networks','templates','storages'].includes(resource)?'<th>Actions</th>':''}</tr></thead><tbody>${data.map(row=>`<tr>${keys.map(k=>`<td>${k==='status'||k==='result'?status(row[k]):h(typeof row[k]==='object'?JSON.stringify(row[k]):row[k]??'—')}</td>`).join('')}${adminActions(resource,row)}</tr>`).join('')}</tbody></table></div>`:empty()}</section>`;
    document.querySelectorAll('#adminCreate input, #adminCreate select, #adminCreate textarea').forEach(field => {
      if (!field.getAttribute('aria-label')) field.setAttribute('aria-label', field.getAttribute('placeholder') || field.name.replaceAll('_', ' '));
    });
    document.getElementById('adminCreate')?.addEventListener('submit', async event => {
      event.preventDefault(); const values=Object.fromEntries(new FormData(event.currentTarget)); event.currentTarget.querySelectorAll('input[type=checkbox]').forEach(x=>values[x.name]=x.checked);
      try { await api(`/api/v1/admin/${resource}`,{method:'POST',body:values});toast(tr.saved);adminResource(resource); } catch(error){toast(error.message,'danger');}
    });
    content.addEventListener('click', async event => {
      const button=event.target.closest('[data-admin-action]');if(!button)return;
      const id=Number(button.dataset.id), action=button.dataset.adminAction;
      try {
        if(action==='sync'){button.disabled=true;await api(`/api/v1/admin/proxmox/${id}/sync`,{method:'POST'});toast(tr.saved);}
        else if(action==='toggle'){await api(`/api/v1/admin/${resource}/${id}`,{method:'PATCH',body:{enabled:button.dataset.enable==='1'}});toast(tr.saved);}
        else if(action==='block'){await api(`/api/v1/admin/users/${id}`,{method:'PATCH',body:{status:button.dataset.status==='blocked'?'active':'blocked',role:button.dataset.role}});toast(tr.saved);}
        else if(action==='reset-password'){const password=prompt(locale==='pl'?'Nowe hasło (min. 12 znaków):':'New password (min. 12 characters):');if(!password)return;await api(`/api/v1/admin/users/${id}`,{method:'PATCH',body:{status:button.dataset.status,role:button.dataset.role,password}});toast(tr.saved);}
        else if(action==='toggle-role'){const role=button.dataset.role==='admin'?'user':'admin';confirmAction(`${tr.confirm} (${role})`,()=>api(`/api/v1/admin/users/${id}`,{method:'PATCH',body:{status:button.dataset.status,role}}).then(()=>{toast(tr.saved);adminResource(resource);}).catch(error=>toast(error.message,'danger')));return;}
        else if(action==='member'){const userId=prompt('User ID:');if(!userId)return;await api(`/api/v1/admin/projects/${id}/members`,{method:'POST',body:{user_id:Number(userId),membership_role:'member'}});toast(tr.saved);}
        else if(action==='project-access'){const networkId=prompt('Network ID (leave empty to skip):')||null;const storageId=prompt('Storage ID (leave empty to skip):')||null;if(!networkId&&!storageId)return;await api(`/api/v1/admin/projects/${id}/access`,{method:'POST',body:{network_id:networkId,storage_id:storageId}});toast(tr.saved);}
        else if(action==='project-details'){const details=await api(`/api/v1/admin/projects/${id}`);const modal=document.getElementById('confirmModal');document.getElementById('confirmTitle').textContent=details.project.name;document.getElementById('confirmMessage').innerHTML=`<h3 class="h6">Members</h3>${details.members.map(x=>`<div class="d-flex justify-content-between align-items-center border-bottom py-2"><span>#${x.id} ${h(x.username)} · ${h(x.membership_role)}</span><button class="btn btn-sm btn-outline-danger" data-remove-project="${id}" data-remove-type="members" data-remove-id="${x.id}">Remove</button></div>`).join('')||empty()}<h3 class="h6 mt-4">Networks</h3>${details.networks.map(x=>`<div class="d-flex justify-content-between align-items-center border-bottom py-2"><span>#${x.id} ${h(x.name)} · ${h(x.bridge)} · VLAN ${h(x.vlan_id||'untagged')}</span><button class="btn btn-sm btn-outline-danger" data-remove-project="${id}" data-remove-type="access/network" data-remove-id="${x.id}">Remove</button></div>`).join('')||empty()}<h3 class="h6 mt-4">Storage</h3>${details.storages.map(x=>`<div class="d-flex justify-content-between align-items-center border-bottom py-2"><span>#${x.id} ${h(x.storage_name)}</span><button class="btn btn-sm btn-outline-danger" data-remove-project="${id}" data-remove-type="access/storage" data-remove-id="${x.id}">Remove</button></div>`).join('')||empty()}`;document.getElementById('confirmAction').classList.add('d-none');document.getElementById('confirmMessage').querySelectorAll('[data-remove-project]').forEach(remove=>remove.addEventListener('click',()=>{bootstrap.Modal.getOrCreateInstance(modal).hide();confirmAction(tr.confirm,async()=>{try{await api(`/api/v1/admin/projects/${remove.dataset.removeProject}/${remove.dataset.removeType}/${remove.dataset.removeId}`,{method:'DELETE'});toast(tr.saved);adminResource('projects');}catch(error){toast(error.message,'danger');}});}));bootstrap.Modal.getOrCreateInstance(modal).show();return;}
        else if(action==='connection-status'){await api(`/api/v1/admin/proxmox/${id}`,{method:'PATCH',body:{status:button.dataset.status==='disabled'?'active':'disabled'}});toast(tr.saved);}
        else if(action==='rotate-secret'){const secret=prompt(locale==='pl'?'Nowy sekret tokenu API:':'New API token secret:');if(!secret)return;await api(`/api/v1/admin/proxmox/${id}`,{method:'PATCH',body:{status:button.dataset.status,api_token_secret:secret}});toast(tr.saved);}
        else if(action==='project-status'){await api(`/api/v1/admin/projects/${id}`,{method:'PATCH',body:{status:button.dataset.status==='active'?'suspended':'active'}});toast(tr.saved);}
        adminResource(resource);
      } catch(error){toast(error.message,'danger');button.disabled=false;}
    });
  }
  function adminActions(resource,row) {
    if(resource==='proxmox')return `<td><div class="actions"><button class="btn btn-sm btn-outline-primary" data-admin-action="sync" data-id="${row.id}">${icon('refresh')}Test / Sync</button><button class="btn btn-sm btn-outline-secondary" data-admin-action="rotate-secret" data-id="${row.id}" data-status="${h(row.status)}">${icon('key')}${locale==='pl'?'Rotuj sekret':'Rotate secret'}</button><button class="btn btn-sm btn-outline-warning" data-admin-action="connection-status" data-id="${row.id}" data-status="${h(row.status)}">${icon('power')}${row.status==='disabled'?'Enable':'Disable'}</button></div></td>`;
    if(resource==='users')return `<td><div class="actions"><button class="btn btn-sm btn-outline-warning" data-admin-action="block" data-id="${row.id}" data-status="${h(row.status)}" data-role="${h(row.role)}">${icon('ban')}${row.status==='blocked'?'Unblock':'Block'}</button><button class="btn btn-sm btn-outline-secondary" data-admin-action="reset-password" data-id="${row.id}" data-status="${h(row.status)}" data-role="${h(row.role)}">${icon('key')}Reset password</button><button class="btn btn-sm btn-outline-primary" data-admin-action="toggle-role" data-id="${row.id}" data-status="${h(row.status)}" data-role="${h(row.role)}">${icon('users')}Set ${row.role==='admin'?'user':'admin'}</button></div></td>`;
    if(resource==='projects')return `<td><div class="actions"><button class="btn btn-sm btn-outline-secondary" data-admin-action="project-details" data-id="${row.id}">${icon('eye')}Details</button><button class="btn btn-sm btn-outline-warning" data-admin-action="project-status" data-id="${row.id}" data-status="${h(row.status)}">${icon('power')}${row.status==='active'?'Suspend':'Activate'}</button><button class="btn btn-sm btn-outline-primary" data-admin-action="member" data-id="${row.id}">${icon('user-plus')}Add member</button><button class="btn btn-sm btn-outline-primary" data-admin-action="project-access" data-id="${row.id}">${icon('link')}Assign network/storage</button></div></td>`;
    if(['plans','networks','templates','storages'].includes(resource))return `<td><button class="btn btn-sm btn-outline-secondary" data-admin-action="toggle" data-id="${row.id}" data-enable="${row.enabled?'0':'1'}">${icon('power')}${row.enabled?'Disable':'Enable'}</button></td>`;
    return '';
  }

  async function infrastructure() {
    const connections = await api('/api/v1/admin/proxmox');
    const nodes = await api('/api/v1/admin/nodes');
    content.innerHTML = `<div class="metric-grid">${metric('Clusters',connections.length)}${metric('Nodes',nodes.length)}${metric('Online',nodes.filter(n=>n.status==='online').length)}${metric('Errors',connections.filter(c=>c.status==='error').length)}</div><section class="panel mt-3"><div class="panel-header"><h2 class="h5 mb-0">Nodes</h2></div><div class="table-responsive"><table class="table"><thead><tr><th>Cluster</th><th>Node</th><th>Status</th><th>CPU</th><th>RAM</th><th>Last seen</th></tr></thead><tbody>${nodes.map(n=>`<tr><td>${h(n.connection_name)}</td><td>${h(n.node_name)}</td><td>${status(n.status)}</td><td>${n.cpu_usage===null?'—':(Number(n.cpu_usage)*100).toFixed(1)+'%'}</td><td>${n.memory_total?`${Math.round(n.memory_used/1073741824)} / ${Math.round(n.memory_total/1073741824)} GB`:'—'}</td><td>${date(n.last_seen_at)}</td></tr>`).join('')||`<tr><td colspan="6">${empty()}</td></tr>`}</tbody></table></div></section>`;
  }

  const loaders = {dashboard, vms:vmList, 'create-vm':createVmWizard, projects:()=>simpleResource('projects'), networks:()=>simpleResource('networks'), templates:()=>simpleResource('templates'), activity, infrastructure, users:()=>adminResource('users'), proxmox:()=>adminResource('proxmox'), storages:()=>adminResource('storages'), plans:()=>adminResource('plans'), quotas:()=>adminResource('quotas'), audit:()=>adminResource('audit'), settings:()=>adminResource('settings')};
  Promise.resolve(loaders[page]?.() || dashboard()).catch(showError);
})();
