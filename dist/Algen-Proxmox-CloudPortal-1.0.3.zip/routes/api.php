<?php

declare(strict_types=1);

use CloudPortal\Application;
use CloudPortal\Controllers\AdminController;
use CloudPortal\Controllers\AuthController;
use CloudPortal\Controllers\CatalogController;
use CloudPortal\Controllers\DashboardController;
use CloudPortal\Controllers\JobController;
use CloudPortal\Controllers\ResourceController;
use CloudPortal\Controllers\VmController;
use CloudPortal\Http\Router;

return static function (Router $router, Application $app): void {
    $auth = new AuthController($app);
    $dashboard = new DashboardController($app);
    $vms = new VmController($app);
    $jobs = new JobController($app);
    $catalog = new CatalogController($app);
    $resources = new ResourceController($app);
    $admin = new AdminController($app);

    $router->add('GET', '/api/v1/me', [$auth, 'me']);
    $router->add('POST', '/api/v1/logout', [$auth, 'logout']);
    $router->add('GET', '/api/v1/dashboard', [$dashboard, 'index']);
    $router->add('GET', '/api/v1/catalog', [$catalog, 'index']);
    $router->add('GET', '/api/v1/vms', [$vms, 'index']);
    $router->add('POST', '/api/v1/vms', [$vms, 'create']);
    $router->add('GET', '/api/v1/vms/{id}', [$vms, 'show']);
    $router->add('DELETE', '/api/v1/vms/{id}', [$vms, 'delete']);
    $router->add('POST', '/api/v1/vms/{id}/snapshots', [$vms, 'snapshot']);
    $router->add('DELETE', '/api/v1/vms/{id}/snapshots/{snapshotId}', [$vms, 'deleteSnapshot']);
    $router->add('POST', '/api/v1/vms/{id}/resize', [$vms, 'resize']);
    $router->add('PATCH', '/api/v1/vms/{id}/assignment', [$vms, 'assign']);
    $router->add('POST', '/api/v1/vms/{id}/console', [$vms, 'console']);
    $router->add('POST', '/api/v1/vms/{id}/{action}', [$vms, 'power']);
    $router->add('GET', '/api/v1/jobs', [$jobs, 'index']);
    $router->add('GET', '/api/v1/jobs/{id}', [$jobs, 'show']);
    $router->add('GET', '/api/v1/{resource}', [$resources, 'index']);

    $router->add('GET', '/api/v1/admin/{resource}', [$admin, 'index']);
    $router->add('GET', '/api/v1/admin/projects/{id}', [$admin, 'project']);
    $router->add('POST', '/api/v1/admin/{resource}', [$admin, 'create']);
    $router->add('PATCH', '/api/v1/admin/{resource}/{id}', [$admin, 'update']);
    $router->add('POST', '/api/v1/admin/proxmox/{id}/sync', [$admin, 'syncProxmox']);
    $router->add('POST', '/api/v1/admin/projects/{id}/members', [$admin, 'projectMembership']);
    $router->add('POST', '/api/v1/admin/projects/{id}/access', [$admin, 'projectAccess']);
    $router->add('DELETE', '/api/v1/admin/projects/{id}/members/{userId}', [$admin, 'removeProjectMembership']);
    $router->add('DELETE', '/api/v1/admin/projects/{id}/access/{type}/{resourceId}', [$admin, 'removeProjectAccess']);
};
