<?php

declare(strict_types=1);

namespace CloudPortal\Services\Provisioning;

use CloudPortal\Database\Database;
use CloudPortal\Http\HttpException;
use CloudPortal\Services\IPAM\IPAMService;
use CloudPortal\Services\Quota\QuotaExceeded;
use CloudPortal\Services\Quota\QuotaService;
use CloudPortal\Support\Uuid;
use PDO;

final class ProvisioningRequestService
{
    public function __construct(private readonly Database $database)
    {
    }

    /** @param array<string,mixed> $input */
    public function createVm(int $userId, bool $isAdmin, array $input): string
    {
        return $this->database->transaction(function (PDO $pdo) use ($userId, $isAdmin, $input): string {
            $projectId = (int) ($input['project_id'] ?? 0);
            $ownerId = $isAdmin && isset($input['owner_user_id']) ? (int) $input['owner_user_id'] : $userId;
            $this->assertMembership($pdo, $projectId, $ownerId);
            if (!$isAdmin && $ownerId !== $userId) {
                throw new HttpException(403, 'A user cannot provision resources for another account.');
            }

            $name = trim((string) ($input['name'] ?? ''));
            if (preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{1,62}$/', $name) !== 1) {
                throw new HttpException(422, 'VM name must contain 2-63 letters, digits or hyphens.');
            }
            $exists = $pdo->prepare("SELECT 1 FROM virtual_machines WHERE project_id = :project AND name = :name AND status <> 'deleted' LIMIT 1");
            $exists->execute(['project' => $projectId, 'name' => $name]);
            if ($exists->fetchColumn()) {
                throw new HttpException(409, 'A VM with this name already exists in the project.');
            }

            $catalog = $this->catalog($pdo, $projectId, $input);
            $reservationKey = Uuid::v4();
            $quota = new QuotaService($pdo);
            $quota->cleanupExpired();
            try {
                $quota->reserve($reservationKey, $projectId, $ownerId, [
                    'vms' => 1,
                    'vcpu' => (int) $catalog['vcpu'],
                    'ram_mb' => (int) $catalog['ram_mb'],
                    'storage_gb' => (int) $catalog['disk_gb'],
                    'ip_addresses' => 1,
                ]);
            } catch (QuotaExceeded $exception) {
                throw new HttpException(409, $exception->getMessage(), ['resource' => $exception->resource]);
            }
            $ip = (new IPAMService($pdo))->reserve((int) $catalog['network_id'], $reservationKey);
            $cloudUser = trim((string) ($input['cloud_init_user'] ?? 'clouduser'));
            if (preg_match('/^[a-z_][a-z0-9_-]{0,31}$/', $cloudUser) !== 1) {
                throw new HttpException(422, 'Invalid cloud-init username.');
            }
            $sshKey = trim((string) ($input['ssh_public_key'] ?? ''));
            if ($sshKey !== '' && preg_match('/^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp(256|384|521)) [A-Za-z0-9+\/=]+(?: .*)?$/', $sshKey) !== 1) {
                throw new HttpException(422, 'Invalid SSH public key.');
            }
            $prefix = $this->prefixFromSubnet((string) $catalog['subnet']);
            $payload = [
                'name' => $name,
                'owner_user_id' => $ownerId,
                'project_id' => $projectId,
                'template_id' => (int) $catalog['template_id'],
                'template_vmid' => (int) $catalog['template_vmid'],
                'node_name' => (string) $catalog['node_name'],
                'plan_id' => (int) $catalog['plan_id'],
                'vcpu' => (int) $catalog['vcpu'],
                'ram_mb' => (int) $catalog['ram_mb'],
                'disk_gb' => (int) $catalog['disk_gb'],
                'network_id' => (int) $catalog['network_id'],
                'bridge' => (string) $catalog['bridge'],
                'vlan_id' => $catalog['vlan_id'] === null ? null : (int) $catalog['vlan_id'],
                'ip_address' => $ip['address'],
                'ip_cidr' => $ip['address'] . '/' . $prefix,
                'gateway' => $catalog['gateway'],
                'dns_servers' => $catalog['dns_servers'],
                'storage_id' => (int) $catalog['storage_id'],
                'storage_name' => (string) $catalog['storage_name'],
                'cloud_init_user' => $cloudUser,
                'ssh_public_key' => $sshKey,
                'start_after_create' => !isset($input['start_after_create']) || filter_var($input['start_after_create'], FILTER_VALIDATE_BOOL),
            ];
            return (new JobRepository($pdo))->enqueue(
                'vm.create', $userId, $projectId, (int) $catalog['connection_id'], $payload, $reservationKey
            );
        });
    }

    private function assertMembership(PDO $pdo, int $projectId, int $userId): void
    {
        $statement = $pdo->prepare(
            "SELECT 1 FROM project_users pu JOIN projects p ON p.id = pu.project_id
             JOIN users u ON u.id = pu.user_id
             WHERE pu.project_id = :project AND pu.user_id = :user AND p.status = 'active' AND u.status = 'active'"
        );
        $statement->execute(['project' => $projectId, 'user' => $userId]);
        if (!$statement->fetchColumn()) {
            throw new HttpException(403, 'The owner is not an active member of this project.');
        }
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private function catalog(PDO $pdo, int $projectId, array $input): array
    {
        $statement = $pdo->prepare(
            "SELECT t.id AS template_id, t.vmid AS template_vmid, t.node_name, t.connection_id,
                    p.id AS plan_id, p.vcpu, p.ram_mb, p.disk_gb,
                    n.id AS network_id, n.bridge, n.vlan_id, n.subnet, n.gateway, n.dns_servers,
                    s.id AS storage_id, s.storage_name
             FROM vm_templates t
             JOIN proxmox_connections c ON c.id = t.connection_id AND c.status = 'active'
             JOIN resource_plans p ON p.id = :plan AND p.enabled = 1
             JOIN networks n ON n.id = :network AND n.connection_id = t.connection_id AND n.enabled = 1 AND (n.node_name IS NULL OR n.node_name = t.node_name)
             JOIN project_networks pn ON pn.network_id = n.id AND pn.project_id = :project
             JOIN storages s ON s.id = :storage AND s.connection_id = t.connection_id AND s.enabled = 1 AND (s.node_name IS NULL OR s.node_name = t.node_name)
             JOIN project_storages ps ON ps.storage_id = s.id AND ps.project_id = :project2
             WHERE t.id = :template AND t.enabled = 1 LIMIT 1"
        );
        $statement->execute([
            'plan' => (int) ($input['plan_id'] ?? 0),
            'network' => (int) ($input['network_id'] ?? 0),
            'project' => $projectId,
            'storage' => (int) ($input['storage_id'] ?? 0),
            'project2' => $projectId,
            'template' => (int) ($input['template_id'] ?? 0),
        ]);
        $catalog = $statement->fetch();
        if (!is_array($catalog)) {
            throw new HttpException(422, 'The selected template, plan, network or storage is unavailable for this project.');
        }
        return $catalog;
    }

    private function prefixFromSubnet(string $subnet): int
    {
        $parts = explode('/', $subnet, 2);
        if (count($parts) !== 2 || filter_var($parts[0], FILTER_VALIDATE_IP) === false) {
            throw new HttpException(500, 'Selected network has an invalid subnet.');
        }
        $max = str_contains($parts[0], ':') ? 128 : 32;
        $prefix = filter_var($parts[1], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => $max]]);
        if ($prefix === false) {
            throw new HttpException(500, 'Selected network has an invalid subnet prefix.');
        }
        return (int) $prefix;
    }
}
